==========================================
Read Me
==========================================

Admin Area Settings :

1. Go to the Currency Settings Page 

		System > Localisation > Currencies

2. Insert/Add  Following details

		Currency Title : Indian Rupee 

		Code : INR  (Must to Set this)

		Symbol Left : Rs (Optional to Set this)

		Symbol Right :   (Must to empty)


3. View your Shop