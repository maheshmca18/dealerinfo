<?php
// Text
$_['text_title']       = 'Shipping Charge';
$_['text_description'] = 'Shipping Charge';
