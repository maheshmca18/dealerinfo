Now works on OpenCart 2.0.x!

Extension Features
==============================================================================================================
The Product Based Individual Shipping Price Modules allows The admin can Create shipping price based on the Product.

This module works on following pages :-
-------------------------------------------
Product Detail Page
Shopping Cart list Page,
Cart Checkout's Shipping Method,
Order Detail Page,
Admin Order View Page,
Admin Order Edit Page,
Admin Order Invoice Bill. 

Requirements
==============================================================================================================
PHP 5.2 or later
OpenCart 2.0.x

