<?php
// Heading
$_['heading_title']       = 'Product Based Shipping';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module Product Based Shipping!';

// Entry

$_['entry_status']        = 'Status';
$_['entry_theme']         = 'Theme:';

$_['error_color']         = 'color Required';


$_['text_enabled'] 	  = 'Enabled';
$_['text_disabled'] 	  = 'Disabled';
?>
