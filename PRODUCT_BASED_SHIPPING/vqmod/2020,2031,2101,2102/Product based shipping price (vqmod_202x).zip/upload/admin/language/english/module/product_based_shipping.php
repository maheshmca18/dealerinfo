<?php
// Heading
$_['heading_title']    = 'Product Based Bhipping';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

$_['text_edit']            = 'Edit Product Based Bhipping Module';
$_['text_module']            = 'Module';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';
