<?php
// Text
$_['text_title']       = 'Product Shipping';
$_['text_description'] = 'Product Shipping';
