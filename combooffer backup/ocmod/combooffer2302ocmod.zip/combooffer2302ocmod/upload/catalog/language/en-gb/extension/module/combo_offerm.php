<?php
// Heading
$_['heading_title'] = 'COMBO OFFER';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['comboprice']    = 'Combo Price : ';
$_['saveamount']    = 'Your Save : ';


$_['menucombo']	    = 'Combo Offer';
$_['option_title']  = 'Following  products have required options';
