<?php
$_['entry_title'] = 'Combo Discount';
