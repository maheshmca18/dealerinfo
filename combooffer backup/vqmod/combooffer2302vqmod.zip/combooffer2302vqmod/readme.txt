Combo Offer Extension for OpenCart 2.3.0.x!

Extension Features
==============================================================================================================
Combo Offer is module for OpenCart. Admin can create unlimited number of Combo Offer. Admin can set discount amount. The Combo Offer have start date and end date to display the offers. The combo offer will show on product page based on the products who have combo offer. If there is no combo offer for the product in details page, it will show the default Home page combo offer details. User can see updated price in the bottom of the cart (Totals) and display the discount price also in bottom of the cart. 

=> Combo offer with carousel widget (Auto scroll and manual)
=> The admin can add one OR more product in the Combo Offer 
=> The Combo Offer with start date and end date
=> Create custom Combo Offer for all your products
=> Handpicked products and set discounts
=> If there is more than one combo offer for a single page, they will be displayed in a random way
=> The module can be displayed on Home,Product and Category layouts
=> Support all kinds of options.
=> Multi-language support.
=> Customers can add more than one combo offer in the cart.
=> The combo offer show on category page based on the category
=> The combo offer show on product page based on the products

Requirements
==============================================================================================================
PHP 5.2 or later
OpenCart 2.3.0.x