<?php
// Heading
$_['heading_title']    = 'DeliveryDateTime';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';
$_['entry_time_interval']     = 'Time Interval';
$_['text_status_enabled']             = 'Enabled';
$_['text_status_disabled']            = 'Disabled';
$_['text_min_day']                    = 'Minimum Day';
$_['text_max_day']                    = 'Maximum Day';
$_['text_edit_DeliveryDateTime']            = 'Edit DeliveryDateTime Module';
$_['text_module']            = 'Module';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';
