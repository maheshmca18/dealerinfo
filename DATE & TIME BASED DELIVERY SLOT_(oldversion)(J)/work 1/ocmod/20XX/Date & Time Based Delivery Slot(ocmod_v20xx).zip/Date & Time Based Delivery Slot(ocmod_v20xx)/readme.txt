==========================================
Date & Time Based Delivery Slot
==========================================

The Date & Time Based Delivery Slot module allows the Delivery Date and Delivery Time field has shows in Delivery Method Tab, On Cart checkout page.

When customer place order with pick his expected delivery date and Delivery Time in Delivery Method Tab, On Cart checkout page.

Main Feature :-
=> It allows the admin user can add Delivery Time Slot for the day.
=> This extension adds Delivery Date and  Delivery Time field in the store front checkout Delivery Method Tab.
=> The customer can pick expected Delivery Date and Delivery Time.
=> Delivery date and Delivery Time is shown in Store front's Orderdetail.
=> Delivery date and Delivery Time is shown in Admin Dashboard's Order detail page.
=> Delivery date and Delivery Time is shown in Order Invoice bill and Order confirmation mail also.

==========================================
Date & Time Based Delivery Slot
==========================================


1. Go to the Extensions -> Modules

		-> Install the DeliveryDateTime Module
              
                -> Edit DeliveryDateTime Module 
                       
		               i) Select Status [ Enabled/Disabled ].
		              
		              ii) Give Time Interval [Integer Value][show frontend Time interval duration].


2.Go to the System -> Users -> User Groups

Select Top Administrator -> Edit
		  
		  Enable the following checkbox,
		  
        		 Access Permission : Localisation/deliverytimeslot   
			 
			 Modify Permission : Localisation/deliverytimeslot   
			 
		  Then Click the Save button.


3. Go to the System -> Localisation -> Delivery Timeslot

                -> Click Insert Button add your  Delivery Timeslot 

			       i) Select From Time

		              ii) Select To Time		        
	 
	 		     iv)  Select Status [ Enabled/Disabled ].

                -> Now Click "Save" button.

4. Go to store front

	-> See the 
                i) Please select the preferred Delivery / Pickup date [Delivery date],

	       ii) Pickup / Delivery Time Slot  field in Delivery Method Tab, On Cart checkout page.

	-> Customer can select his prefer delivery date and delivery time 
	

5. Go to store front Order detail page and see the Delivery Date and Delivery Time appears.

6. Go to Order List [ Admin -> Sales -> Orders ]

       -> Click the view button in Orders list and see the Delivery Date and Delivery Time in order detail.
       -> Click the Print Invoice button and see the Delivery Date and Delivery Time appears in Invoice bill.
       -> Click the Edit  button and see the Delivery Date and Delivery Time appears Shipping Details Tab.
       -> Order confirmation mail also appears the Delivery Date and Delivery Time field.


