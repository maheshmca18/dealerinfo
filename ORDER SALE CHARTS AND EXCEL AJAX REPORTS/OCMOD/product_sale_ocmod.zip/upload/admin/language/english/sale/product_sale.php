<?php
// Heading
$_['heading_title']          = 'Product Sale';

//Entry
$_['entry_product_category'] = 'Category';
$_['text_list']              = 'Product Sale List';
$_['entry_status']           = 'Status';
$_['text_product_sale']       = 'Product Sale';
$_['entry_date_added']        = 'Start Date';
$_['entry_date_modified'] =  'End Date';
$_['entry_product_name'] =  'Product Name';
$_['entry_product_id'] =  'Product ID';
$_['entry_total_quantity'] =  'Total Quantity';
$_['entry_orders'] =  'Total Orders';
$_['entry_category_id'] =  'Category ID';
$_['entry_category_name'] =  'Category Name';

// Error
$_['text_no_results'] = 'No results!';

