<?php
// Heading
$_['heading_title']    = 'Order Sale Charts and Excel Ajax reports';

$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Order Sale Charts and Excel Ajax reports module!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Order Sale Charts and Excel Ajax reports module!';