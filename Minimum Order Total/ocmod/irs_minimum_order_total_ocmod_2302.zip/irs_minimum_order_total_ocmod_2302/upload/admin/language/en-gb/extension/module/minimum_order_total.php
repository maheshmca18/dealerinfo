<?php
// Heading
$_['heading_title']    = 'Minimum Order Total';

$_['text_module']      = 'Modules';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Minimum Order Total module!';
$_['text_edit']        = 'Edit Minimum Order Total Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Minimum Order Total module!';
