IRS Minimum Order Total Extension for OpenCart 2.0.x!

Extension Features
==============================================================================================================
IRS Minimum Order Total Extension effectively set the minimum order amount per Geo Zone . This extension also allows you restrict the minimum purchase amount for each customer zone.Also Customers cannot place an order that has a total of less than a specified sum of money.

=> Individual Settings per Geo Zone Based Minimum Order Total
=> If any of the limit checks are not met or exceed, a warning is shown on the cart page
=> The customer cannot continue until the min rules are met.
=> check based on order total (final value, include discount, vouchers etc)
=> VQMOD / OCMOD compatibility.

Requirements
==============================================================================================================
PHP 5.2 or later
OpenCart 2.0.x
