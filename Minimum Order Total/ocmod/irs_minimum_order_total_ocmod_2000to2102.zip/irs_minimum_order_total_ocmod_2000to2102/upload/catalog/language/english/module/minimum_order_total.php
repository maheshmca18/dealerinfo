<?php
// Heading
$_['heading_title']    = 'Minimum Order Total';

// Error
$_['error_minimum_order_total'] = 'Minimum order total accepted is ';