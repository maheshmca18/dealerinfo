=======================================================
Bulk Import/Export 2.X To 2.X
=======================================================

Admin Login :

=======================================================
Categories Import & Export
=======================================================

1. Go to the Category list Page 

		Catalog -> Categories

	        See Import Button & Export Button Top Right corner.

2. Click to Export Button and Export Categories list as excel file (downloaded).

3. Click to Import Button

		-> View Categories Import Screen.

		-> Click "Sample CSV file" on the Top Right corner to Categorieslist sample excel/CSV file (downloaded).

                -> Upload your Excel/CSV file [Note: Like our Sample file].

                -> Click Save button on Top Right corner.
 
 		-> Preview Your uploaded file Categories data.

                -> Now Click "Publish" button to import all Categories data.



=======================================================
Products Import & Export
=======================================================

1. Go to the Products list Page 

		Catalog -> Products

	        See Import Button & Export Button Top Right corner.

2. Click to Export Button and Export Products list as excel file (downloaded).

3. Click to Import Button

		-> View Products Import Screen.

		-> Click "Sample CSV file" on the Top Right corner to Productslist sample excel/CSV file (downloaded).

                -> Upload your Excel/CSV file [Note: Like our Sample file].

                -> Click Save button on Top Right corner.
 
 		-> Preview Your uploaded file Products data.

                -> Now Click "Publish" button to import all Products data.


=======================================================
Customer Import & Export
=======================================================


1. Go to the Customer list Page 

		Sales -> Customers -> Customer 
              
                See Import Button & Export Button Top Right corner.


2. Click to Export Button and  Export Customers list as excel file (downloaded).

3. Click to Import Button 

                -> View Customers Import Screen.

		-> Click "Sample CSV file" on the Top Right corner to Customerslist sample excel/CSV file (downloaded).

                -> Upload your Excel/CSV file [Note: Like our Sample file].

                -> Click Save button on Top Right corner.
 
 		-> Preview Your uploaded file Customers data.

                -> Now Click "Publish" button to import all Customers data.


=======================================================
Orders Import & Export
=======================================================


1. Go to the Orders list Page 

		Sales -> Orders 
              
                See Import Button & Export Button Top Right corner.


2. Click to Export Button and  Export Orders list as excel file (downloaded).

3. Click to Import Button 

                -> View Orders Import Screen.

		-> Click "Sample CSV file" on the Top Right corner to Orderslist sample excel/CSV file (downloaded).

                -> Upload your Excel/CSV file [Note: Like our Sample file].

                -> Click Save button on Top Right corner.
 
 		-> Preview Your uploaded file Orders data.

                -> Now Click "Publish" button to import all Orders data.
		
------------------------------------------------------------------------------------------------------------------------
				Categories CSV File 
------------------------------------------------------------------------------------------------------------------------
		1. Category Name[valid Category]
		2. Description
		3. Meta_description
		4. Meta_keyword
		5. Parent ID
		6. Image
		7. Column
		8. Sort Order
		9. Status

------------------------------------------------------------------------------------------------------------------------
				Products CSV File 
------------------------------------------------------------------------------------------------------------------------
		1. Product Name
		2. Description
		3. Meta_description
		4. Meta_keyword
		5. tag
		6. model
		7. sku
		8. upc
		9. ean
		10. jan
		11. isbn
		12. mpn
		13. location
		14. quantity
		15. stock_status_id
		16. product_image_path
		17. require_shipping
		18. price
		19. tax_class_id
		20. date_available
		21. weight
		22. weight_class_id
		23. length
		24. width
		25. height
		26. length_class_id
		27. subtract
		28. minimum
		29. sort_order
		30. viewed
		31. points
		32. status
		33. Manufacturer Name
		34. Category Name
		35. Additional Image
		36. Select Type
		37. Required
		38. Option Value
		39. Quantity
		40. Subtrack stock
		41. Price
		42. Price Prefix
		43. Ponits
		44. Ponits Prdefix
		45. Weight
		46. weight Prefix

------------------------------------------------------------------------------------------------------------------------
				Customer CSV File 
------------------------------------------------------------------------------------------------------------------------
		1. Store_id
		2. Customer FirstName
		3. Customer LastName
		4. Email
		5. Telephone
		6. Fax
		7. Password
		8. Salt
		9. Wishlist
		10. Newsletter
		11. Customer_group_id
		12. IP
		13. Status
		14. Approved
		15. Address Firstname
		16. Address Lastname
		17. Company
		18. Company_id
		19. Tax Id
		20. Address 1
		21. Address 2
		22. City
		23. Postcode
		24. Country[valid country code]
		25. Zone[valid zone code]


------------------------------------------------------------------------------------------------------------------------
				Orders CSV File 
------------------------------------------------------------------------------------------------------------------------
		1. Invoice_no
		2. Currency	
		3. Customer	
		4. Customer Group	
		5. Customer First Name	
		6. Customer Last Name	
		7. Customer E-Mail	
		8. Customer Telephone	
		9. Customer Fax	
		10. Product	
		11. Quantity	
		12. Total	
		13. Product option Name	
		14. Product option Value	
		15. Product option Type

		16. Voucher Description
		17. Voucher Code	
		18. Voucher Recipient Name		
		19. Voucher Recipient Email	
		20. Voucher Senders Name	
		21. Voucher Senders Email	
		22. Voucher Gift Certificate Theme	
		23. Voucher Message	
		24. Voucher Amount
	
		25. payment First Name
		26. payment Last Name
		27. payment Company	
		28. payment Address 1
		29. payment Address 2	
		30. payment City	
		31. payment Postcode	
		32. payment Country	
		33. payment Region / State
	
		34. Shipping First Name	
		35. Shipping Last Name
		36. Shipping Company
		37. Shipping Address 1
		38. Shipping Address 2
		39. Shipping City
		40. Shipping Postcode
		41. Shipping Country
		42. Shipping Region / State
		43. Shipping Method
		44. Payment Method
		45. Coupon
		46. Voucher
		47. Reward
		48. Order Status
		49. Comment
		50. Affiliate
		51. Code
		52. Title
		53. Value

-----------------------------------------------------------------------------------------------------------------------



























		
