==========================================
Read Me : Export Excel or CSV
==========================================

Admin Login :

1. Go to the Customers list Page 

		Sales> Customers > Customers

		See export button and click to export customers list as excel file (downloaded).





2. Go to the Orders list Page 

		Sales> Orders

		See export button and click to export Oders list as excel file (downloaded).