===============================================================================================
		Read Me : Export Excel or CSV
===============================================================================================

Admin Login :
-----------------------------------------------------------------------------------------------
Sales Section 
-----------------------------------------------------------------------------------------------
1. Go to the Orders list Page 

		Sales > Orders

		See export button and click to export Oders list as excel file (downloaded).

2. Go to the Returns list Page 

		Sales > Returns

		See export button and click to export Returns list as excel file (downloaded).

3. Go to the Customers list Page 

		Sales> Customers > Customers

		See export button and click to export customers list as excel file (downloaded).

4. Go to the Affliates list Page 

		Sales> Affliates

		See export button and click to export Affliates list as excel file (downloaded).

5. Go to the Coupons list Page 

		Sales> Coupons

		See export button and click to export Coupons list as excel file (downloaded).

6. Go to the Gift Vouchers list Page 

		Sales> Gift Vouchers > Gift Vouchers

		See export button and click to export Gift Vouchers list as excel file (downloaded).