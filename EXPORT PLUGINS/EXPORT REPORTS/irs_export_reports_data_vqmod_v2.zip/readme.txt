===============================================================================================
	Read Me : Export Excel or CSV
===============================================================================================

Admin Login :
-----------------------------------------------------------------------------------------------
Report Section
-----------------------------------------------------------------------------------------------
1. Go to the Sales Report Page 

		Reports > Sales > Orders

		See export button and click to export Sales Report as excel file (downloaded).

2. Go to the Tax Report Page 

		Reports > Sales > Tax

		See export button and click to export Tax Report as excel file (downloaded).

3. Go to the Shipping Report Page 

		Reports > Sales > Shipping

		See export button and click to export Shipping Report as excel file (downloaded).

4. Go to the Returns Report Page 

		Reports > Sales > Returns

		See export button and click to export Returns Report as excel file (downloaded).

5.Go to the Coupon Report Page 

		Reports > Sales > Coupons

		See export button and click to export Coupons Report as excel file (downloaded).

6. Go to the Products Purchased Report Page 

		Sales > Products > Purchased

		See export button and click to export Products Purchased Report as excel file (downloaded).

7. Go to the Customers Online Report Page 

		Reports > Customers > Customers Online

		See export button and click to export Customers Online Report as excel file (downloaded).

8. Go to the Customer Orders Report Page 

		Reports > Customers > Orders

		See export button and click to export Customer Orders Report as excel file (downloaded).

9.Go to the Customer Reward Points Report Page 

		Reports > Customers > Reward Points

		See export button and click to export Customer Reward Points Report as excel file (downloaded).

10. Go to the Customer Credit Report Page 

		Reports > Customers > Credit

		See export button and click to export Customer Credit Report as excel file (downloaded).

11. Go to the Affiliate Commission Report Page 

		Reports > Affiliate > Commission

		See export button and click to export Affiliate Commission Report as excel file (downloaded).