===============================================================================================
			Read Me : Export Excel or CSV
===============================================================================================

Admin Login :
-----------------------------------------------------------------------------------------------
Catalog Section
-----------------------------------------------------------------------------------------------
1. Go to the Categories list Page 

		Catalog > Categories

		See export button and click to export Category list as excel file (downloaded).

2. Go to the Products list Page 

		Catalog > Products

		See export button and click to export Products list as excel file (downloaded).