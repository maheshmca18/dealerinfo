<?php
// Heading 
$_['heading_title']    = 'Postcode Search';
$_['text_search_postcode'] = 'Search Your Postcode';
?>
