<?php
// Heading
$_['heading_title']          = 'Postcodes';

// Text
$_['text_success']           = 'Success: You have modified Postcode!';

$_['column_action']          = 'Action';

// Entry
$_['entry_status']           = 'Postcode Status:';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify Postcodes!';
?>