==========================================
Product Price Including Tax
==========================================
This Plugin requires "vQmod".

The Product Price Including Tax Modules allows, The Product Price Including Tax Prices that allows to show Price including all tax. 

This Modules reflected following pages,

    -> Product Detail page
    -> Category Page
    -> Search Page
    -> Featured Page
    -> Cart Page
    -> Cart Confirm Page
    -> Order History Page
    -> Admin Order Info Page
    -> Admin Order Invoice Page

It display on yourstore front using Enable/Disable Modules.

==========================================
Product Price Including Tax
==========================================

1. Go to the Extensions -> Modules

		-> Install the Product Price Including Tax Module
              
                -> Edit Product Price Including Tax Module 
                       
		          i) Select Status [ Enabled/Disabled ].      	              





