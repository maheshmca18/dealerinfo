	<?php
// Heading
$_['text_extension']    = 'Extensions';
$_['heading_title']    = 'Product Price Including Tax ';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Product Price Including Tax module!';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Product Price Including Tax!';
$_['text_edit']        = 'Edit Product Price Including Tax Module';


$_['text_status_enabled']             = 'Enabled';
$_['text_status_disabled']            = 'Disabled';

// Entry
$_['entry_admin']      = 'Label Option';
$_['entry_status']     = 'Status';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Product Price Including Tax!';
