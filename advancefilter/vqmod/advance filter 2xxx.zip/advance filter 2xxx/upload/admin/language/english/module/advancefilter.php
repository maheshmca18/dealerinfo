<?php
// Heading
$_['heading_title']       = 'Advance Filter';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module Advance Filter!';

// Entry

$_['entry_status']        = 'Advance Filter Status:';
$_['entry_theme']        = 'Theme:';
$_['entry_brandstatus']        = 'Brand Status:';
$_['entry_pricestatus']        = 'Price Status:';
$_['entry_optionstatus']        = 'Option Status:';
$_['entry_attributestatus']        = 'Attribute Status:';
$_['entry_customerstatus']        = 'Customer Rating Status:';
$_['entry_discountstatus']        = 'Discount Status:';
$_['entry_avilablitystatus']        = 'Availability Status:';

$_['error_color']    = 'color Required';


$_['text_enabled'] 		  = 'Enabled';
$_['text_disabled'] 	  = 'Disabled';
?>
