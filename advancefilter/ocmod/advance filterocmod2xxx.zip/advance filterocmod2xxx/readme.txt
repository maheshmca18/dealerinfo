Now works on OpenCart 2.0.x!

Extension Features
==============================================================================================================
Suitable for catalogues who wants to add an opportunity to filter the product.With this module you can easily filter your product items by the values from the extra fields, by category . You can choose to filter the items from one or several categories. You also have the option to choose exactly which specific items to be available for filtration. "Advance Filter" allows you to filter by one or several fields. 

Configuring all the filter Options and Attributes enable/disable from admin, and also you can configure the filters based on the category and global configuration as well.

FILTER BY
- Manufacturers (brands)
- Price 
- Attributes
- Options
- Rating
- Discount
- Stock status


DEMO
==============================================================================================================
Admin Access
------------
http://ocdemo.indialocal.co.in/opc2020/admin/
user: advancefilter
pass: advancefilter

Front End 
---------
http://ocdemo.indialocal.co.in/opc2020/index.php?route=product/category&path=20


Requirements
==============================================================================================================
PHP 5.2 or later
OpenCart 2.0.x


UPDATE (24-03-2016)
===================
**Added admin configuration Features
**Global Settings
**Category wise Configuration
**Filter Color Changes