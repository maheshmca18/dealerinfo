<?php
// Heading
$_['heading_title']    = 'GlobalCategoryDiscount';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';
$_['text_status_enabled']             = 'Enabled';
$_['text_status_disabled']            = 'Disabled';
$_['text_module']            = 'Module';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';
