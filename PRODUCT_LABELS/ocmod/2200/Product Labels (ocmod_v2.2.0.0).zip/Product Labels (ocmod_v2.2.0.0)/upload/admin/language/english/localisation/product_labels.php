<?php
// Heading
$_['heading_title']     = 'Product Labels';

// Text
$_['text_success']      = 'Success: You have modified Product Labels!';

$_['text_addlabel']         = 'Add Label Properties';
$_['text_label_id']         = 'Label Id';
$_['text_addlabel']         = 'Enabled';
$_['text_disabled']         = 'Disabled';
$_['text_label_id']         = 'Label Id';
$_['text_addnew']         = 'Product New';
$_['text_addshipping']         = 'Product Shipping';
$_['text_adddiscount']         = 'Product Discount';
$_['text_label_text']         = 'Label Text';
$_['text_label_color']         = 'Label color';
$_['text_label_text_color']         = 'Label Text color';
$_['text_label_conditiontype']         = 'Condition Type';

// Column
$_['column_name']       = 'Language Name';
$_['column_code']       = 'Code';
$_['column_sort_order'] = 'Sort Order';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify languages!';
$_['error_name']        = 'Please give holiday name  !';
$_['error_date']        = 'Please give holiday date..!';


