Now works on OpenCart 2.3.0.x!

Extension Features
==============================================================================================================
This extension replaces the pagination on store category, search, special offer  with endless scrolling 
Many users never clicks to second or third pages, don't worry with this extension they will see only one page.
And never have to make additional clicks to see more products. It works just like Google Reader or Image search . 

Features

    Endless scrolling on category, search, special 
    Lazy image loading
    Stateful scrolling
    Several times faster than regular pagination!
    Fade in loaded products 

DEMO
==============================================================================================================
Admin Access
------------
http://ocdemo.indialocal.co.in/opc2011/admin/index.php?route=extension/module&token=87ca4836c28ad7f15d0b0ab6e602f66f
user: endless
pass: endless

Front End 
---------
http://ocdemo.indialocal.co.in/opc2011/index.php?route=product/category&path=20


Requirements
==============================================================================================================
PHP 5.2 or later
OpenCart 2.0.x

In case of problems, please contact me at opencartsupport@irssoft.com

Thank you!


