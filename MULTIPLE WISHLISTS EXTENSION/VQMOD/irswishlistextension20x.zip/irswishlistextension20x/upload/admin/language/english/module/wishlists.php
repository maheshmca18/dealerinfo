<?php
// Heading
$_['heading_title']    = 'Multiple Wishlists';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Multiple Wishlists module!';
$_['text_edit']        = 'Edit Multiple Wishlists Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_social_share']     = 'Choose Social share';
$_['entry_wishlists_copy_url_status']     = 'Do you want Show copy URL';




// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Multiple Wishlists module!';
