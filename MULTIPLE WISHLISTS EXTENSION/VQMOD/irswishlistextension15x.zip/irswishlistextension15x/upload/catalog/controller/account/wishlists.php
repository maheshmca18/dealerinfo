<?php
class ControllerAccountWishLists extends Controller {
	public function index() {
		
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/wishlists', '', 'SSL');

			$this->response->redirect($this->url->link('account/login', '', 'SSL'));
		}

		$this->load->language('account/wishlists');

		$this->load->model('account/wishlists');

        $this->load->model('catalog/product');

		$this->load->model('tool/image');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->data['breadcrumbs'] = array();

		$this->data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home'),
			'separator' => false
		);

		$this->data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', 'SSL'),
			'separator' => $this->language->get('text_separator')
		);

		$this->data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('account/wishlists'),
			'separator' => $this->language->get('text_separator')
		);

        if (isset($this->request->get['remove'])) {

            $remove_id = $this->request->get['remove'];

            $this->model_account_wishlists->removeWishlist($remove_id);

            $this->session->data['success'] = $this->language->get('text_remove');

            $this->response->redirect($this->url->link('account/wishlists'));
        }

		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_empty'] = $this->language->get('text_empty');
        $this->data['text_visiblity_private'] = $this->language->get('text_visiblity_private');
        $this->data['text_visiblity_public'] = $this->language->get('text_visiblity_public');

		$this->data['column_image'] = $this->language->get('column_image');
		$this->data['column_name'] = $this->language->get('column_name');
		$this->data['column_model'] = $this->language->get('column_model');
		$this->data['column_stock'] = $this->language->get('column_stock');
		$this->data['column_price'] = $this->language->get('column_price');
		$this->data['column_action'] = $this->language->get('column_action');
        $this->data['column_share'] = $this->language->get('column_share');


        $this->data['column_name'] = $this->language->get('column_name');
        $this->data['column_visiblity'] = $this->language->get('column_visiblity');
        $this->data['column_action'] = $this->language->get('column_action');
        $this->data['column_purchasecount'] = $this->language->get('column_purchasecount');
        $this->data['column_status'] = $this->language->get('column_status');


		$this->data['button_continue'] = $this->language->get('button_continue');
		$this->data['button_cart'] = $this->language->get('button_cart');
		$this->data['button_remove'] = $this->language->get('button_remove');

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		$this->data['wishlists'] = array();

        $results = $this->model_account_wishlists->getWishlists();
        
		foreach ($results as $result) {

            $totalitems = $this->model_account_wishlists->getCurrentWishlistItemsCount($result['wishlist_id']);
            $boughtitems = $this->model_account_wishlists->getCurrentWishlistPurchasedItemsCount($result['wishlist_id'],0,$result['customer']);

            $this->data['wishlists'][] = array(
                'wishlist_id'   => $result['wishlist_id'],
                'wishlist_name' => $result['wishlist_name'],
                'visiblity'     => $result['visiblity'],
                'status'        => $result['status'],
                'purchasecount' => $boughtitems."/".$totalitems,
                'href'          => $this->url->link('account/wishlists/mywishlist', 'wishlist_id=' . $result['wishlist_id']),
                'remove'        => $this->url->link('account/wishlists', 'remove=' . $result['wishlist_id'])
            );

		}
		
		$this->data['continue'] = $this->url->link('account/account', '', 'SSL');

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/account/wishlists.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/account/wishlists.tpl';
		} else {
			$this->template = 'default/template/account/wishlists.tpl';
		}

		$this->children = array(
			'common/column_left',
			'common/column_right',
			'common/content_top',
			'common/content_bottom',
			'common/footer',
			'common/header'	
		);

		$this->response->setOutput($this->render());	
	}

    public function mywishlist() {

        $wishlist_id = $this->request->get['wishlist_id'];
        
        $this->load->language('account/wishlists');

        $this->load->model('account/wishlists');

        $this->load->model('catalog/product');

        $this->load->model('tool/image');

        $this->document->setTitle($this->language->get('heading_title'));

        $wishlist_info = $this->model_account_wishlists->getWishlist($wishlist_id);

        if (!$this->customer->isLogged() && $wishlist_info['visiblity'] != 1) {

            $this->session->data['redirect'] = $this->url->link('account/wishlists', '', 'SSL');

            $this->response->redirect($this->url->link('account/login', '', 'SSL'));
        }
        
        $customer = $wishlist_info['customer'];

        $wishlist_name = $wishlist_info['wishlist_name'];

        $this->data['breadcrumbs'] = array();

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home'),
			'separator' => $this->language->get('text_separator')
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account', '', 'SSL'),
			'separator' => $this->language->get('text_separator')
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('account/wishlists'),
			'separator' => $this->language->get('text_separator')
        );

        $data['breadcrumbs'][] = array(
            'text' => $wishlist_name,
            'href' => $this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id),
			'separator' => false
        );

        $this->data['visiblity'] = $wishlist_info['visiblity'];

        $this->data['mysharelink'] = $this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id);

        if (isset($this->request->get['remove'])) {
            $remove_id = $this->request->get['remove'];

            $this->model_account_wishlists->removeWishlistitem($wishlist_id,$remove_id);

            $this->session->data['success'] = $this->language->get('text_remove');

            $this->response->redirect($this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id));
        }

        $this->data['islogged'] = ($this->customer->isLogged())?$this->customer->getId():0;

        $this->data['created_on'] = date("d/m/Y",strtotime($wishlist_info['created_on']));

        $this->load->model("account/customer");

        $customerdata = $this->model_account_customer->getCustomer($wishlist_info['created_by']);

        $this->data['created_by'] = '';
        
        if($customerdata){
			
			$this->data['created_by'] = $customerdata['firstname']." ".$customerdata['lastname'];
			
        }

        $this->data['heading_title'] = $wishlist_name;

        $this->data['text_empty'] = $this->language->get('text_empty');
        $this->data['text_tax'] = $this->language->get('text_tax');

        $this->data['column_image'] = $this->language->get('column_image');
        $this->data['column_name'] = $this->language->get('column_name');
        $this->data['column_model'] = $this->language->get('column_model');
        $this->data['column_stock'] = $this->language->get('column_stock');
        $this->data['column_price'] = $this->language->get('column_price');
        $this->data['column_action'] = $this->language->get('column_action');

        $this->data['column_name'] = $this->language->get('column_name');
        $this->data['column_visiblity'] = $this->language->get('column_visiblity');
        $this->data['column_action'] = $this->language->get('column_action');
        $this->data['column_purchasecount'] = $this->language->get('column_purchasecount');
        $this->data['column_status'] = $this->language->get('column_status');

        $this->data['button_continue'] = $this->language->get('button_continue');
        $this->data['button_cart'] = $this->language->get('button_cart');
        $this->data['button_remove'] = $this->language->get('button_remove');

        if (isset($this->session->data['success'])) {
            $this->data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $this->data['success'] = '';
        }

        $this->data['wishlistitems'] = array();
        
        $this->data['is_owner'] = ($this->data['islogged'] == $customer)?1:0;

        $results = $this->model_account_wishlists->getWishlistItems($wishlist_id,"All");

        $product_total = count($results);

        foreach ($results as $result) {

            $purchase_count = $this->model_account_wishlists->getCurrentWishlistPurchasedItemsCount($wishlist_id,$result['product_id'],$customer);

            $product_info = $this->model_catalog_product->getProduct($result['product_id']);

            $is_bought = $this->model_account_wishlists->isproductpurchased($wishlist_id,$result['product_id'],$customer);

            $purchased_by = $this->model_account_wishlists->getCustomerName($is_bought);
            
            
            if(is_array($is_bought)){
                $bought_by = $this->model_account_wishlists->getCustomerName($is_bought['purchased_by']);
                $bought_on = ($is_bought['purchased_on']== '')? '' : " On ".date("d/m/Y H:m:s",strtotime($is_bought['purchased_on'])) ;

                $purchased_by =  ($customer == $is_bought['purchased_by']) ? "Purchased by ".$bought_by.$bought_on : "Purchased by ".$bought_by.$bought_on;

                $is_bought =$is_bought['purchased_by'];
            }

            if ($product_info) {

                if ($product_info['image']) {
                    $image = $this->model_tool_image->resize($product_info['image'], $this->config->get('config_image_wishlist_width'), $this->config->get('config_image_wishlist_height'));
                } else {
                    $image = false;
                }
                
                if ($product_info['price']) {
					$price = $this->currency->format($this->tax->calculate($product_info['price'], $product_info['tax_class_id'], $this->config->get('config_tax')));
				} else {
					$price = false;
				}

				if ((float)$product_info['special']) {
					$special = $this->currency->format($this->tax->calculate($product_info['special'], $product_info['tax_class_id'], $this->config->get('config_tax')));
				} else {
					$special = false;
				}

                if ($this->config->get('config_tax')) {
                    $tax = $this->currency->format((float)$product_info['special'] ? $product_info['special'] : $product_info['price']);
                } else {
                    $tax = false;
                }

                $this->data['wishlistitems'][] = array(
                    'product_id'   => $result['product_id'],
                    'product_name' => $product_info['name'],
                    'thumb'      => $image,
                    'price' => $price,
                    'minimum' => $product_info['minimum'],
                    'special' => $special,
                    'tax' => $tax,
                    'purchase_count' => $purchase_count,

                    'is_bought' => $is_bought,
                    'customer' => $customer,
                    'purchased_by' => $purchased_by,

                    'href'       => $this->url->link('product/product', 'product_id=' . $product_info['product_id']),
                    'remove'        => $this->url->link('account/wishlists/mywishlist', 'remove=' . $result['product_id']."&wishlist_id=".$wishlist_id)
                );

            }
        }


        $this->data['social_list'] = array(
            'fb'=>'facebook',
            'tw'=>'twitter',
            'gp'=>'google',
            'li'=>'linkedin',
            'tm'=>'tumblr',
            'pt'=>'pinterest',
        );

        $this->data['wishlists_status']=$this->config->get('wishlists_status');
        $this->data['wishlists_copy_url_status']=$this->config->get('wishlists_copy_url_status');
        $this->data['wishlists_socials']=($this->config->get('wishlists_socials') != '')?explode(",",$this->config->get('wishlists_socials')):array();

        $page = 1;
        $limit = 10;

        $url = '';
        
        /*
        $pagination = new Pagination();
        $pagination->total = $product_total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->url = $this->url->link('account/wishlists/mywishlist&wishlist_id='.$wishlist_id);
*/
   //     $this->data['pagination'] = $pagination->render();

        $this->data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($product_total - $limit)) ? $product_total : ((($page - 1) * $limit) + $limit), $product_total, ceil($product_total / $limit));

        $this->data['limit'] = $limit;
        $this->data['total'] = $product_total;
        $this->data['page'] = $page;
        $this->data['url'] = $this->url->link('account/wishlists/mywishlist&wishlist_id='.$wishlist_id);
/*
        $this->data['column_left'] = $this->load->controller('common/column_left');
        $this->data['column_right'] = $this->load->controller('common/column_right');
        $this->data['content_top'] = $this->load->controller('common/content_top');
        $this->data['content_bottom'] = $this->load->controller('common/content_bottom');
        $this->data['footer'] = $this->load->controller('common/footer');
        $this->data['header'] = $this->load->controller('common/header');
*/
		$this->data['continue'] = $this->url->link('account/account', '', 'SSL');

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/account/mywishlists.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/account/mywishlists.tpl';
		} else {
			$this->template = 'default/template/account/mywishlists.tpl';
		}

		$this->children = array(
			'common/column_left',
			'common/column_right',
			'common/content_top',
			'common/content_bottom',
			'common/footer',
			'common/header'	
		);

		$this->response->setOutput($this->render());	
    }

	public function add() {

		$this->load->language('account/wishlists');

		$json = array();

        if (isset($this->request->post['wishlist_name'])) {
            $wishlist_name = $this->request->post['wishlist_name'];
        } else {
            $wishlist_name = '';
        }

        if (isset($this->request->post['wishlist_id'])) {
            $wishlist_id = $this->request->post['wishlist_id'];
        } else {
            $wishlist_id = 0;
        }

		if (isset($this->request->post['product_id'])) {
			$product_id = $this->request->post['product_id'];
		} else {
			$product_id = 0;
		}

        $this->load->model('account/wishlists');

		$this->load->model('catalog/product');

        $product_info = $this->model_catalog_product->getProduct($product_id);

		if ($product_info) {

            if ($this->customer->isLogged()) {

                $customer = $this->customer->getId();

                $wishlist_id = ($wishlist_id ==0)?$this->model_account_wishlists->getWishlistId($wishlist_name,$customer):$wishlist_id;

                $wishlists = $this->model_account_wishlists->getWishlistItems($wishlist_id);

                if ($wishlist_id){ //Existing wishlists

                    $wishlist_name = ($wishlist_name == '')?$this->model_account_wishlists->getWishlistName($wishlist_id):$wishlist_name;

                    if(!in_array($product_id, $wishlists) ){

                        $this->model_account_wishlists->addWishlistitem($product_id,$wishlist_id);

                        $json['success'] = sprintf($this->language->get('text_success'), $this->url->link('product/product', 'product_id=' . (int)$this->request->post['product_id']), $product_info['name'], $this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id), $wishlist_name);

                    }else {
                        $json['info'] = sprintf($this->language->get('text_exists'), $this->url->link('product/product', 'product_id=' . (int)$this->request->post['product_id']), $product_info['name'],$this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id), $wishlist_name);
                    }

                }
                else{ // New Wishlists
                    $data_wishlist = array(
                        'wishlist_name' => $wishlist_name,
                        'visiblity' => 1,
                        'status' => 1
                    );

                    $wishlist_id=$this->model_account_wishlists->addWishlists($data_wishlist);

                    $this->model_account_wishlists->addWishlistitem($product_id,$wishlist_id);

//                    $json['success'] = sprintf($this->language->get('text_success'), $this->url->link('product/product', 'product_id=' . (int)$this->request->post['product_id']), $product_info['name'], $this->url->link('account/wishlists/mywishlist'));

                    $json['success'] = sprintf($this->language->get('text_success'), $this->url->link('product/product', 'product_id=' . (int)$this->request->post['product_id']), $product_info['name'], $this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id), $wishlist_name);

                }
            } else {

//                $json['info'] = sprintf($this->language->get('text_login'), $this->url->link('account/login', '', 'SSL'), $this->url->link('account/register', '', 'SSL'), $this->url->link('product/product', 'product_id=' . (int)$this->request->post['product_id']), $product_info['name'], $this->url->link('account/wishlist'));
                $json['info'] = sprintf($this->language->get('text_exists'), $this->url->link('product/product', 'product_id=' . (int)$this->request->post['product_id']), $product_info['name'],$this->url->link('account/wishlists/mywishlist','wishlist_id='.$wishlist_id), $wishlist_name);
            }

 //           $wishlists = $this->model_account_wishlists->getWishlistItems($wishlist_id);

//			$json['total'] = sprintf($this->language->get('text_wishlist'), (is_array($wishlists) ? count($wishlists) : 0));
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

//Edit wishlist
	public function edit() {

        $this->load->model('account/wishlists');

        $this->load->model('catalog/product');

        $json = array();

        $data['text_success'] = $this->language->get('text_success');

        if (isset($this->request->post['wishlist_id'])) {
            $wishlist_id = $this->request->post['wishlist_id'];
        } else {
            $wishlist_id = 0;
        }

        if($wishlist_id != 0) {

            $data['wishlist_id'] = $wishlist_id;

            $wishlist = $this->model_account_wishlists->getWishlist($wishlist_id);

            if ($wishlist) {

                if (isset($this->request->post['wishlist_name'])) {
                    $data['wishlist_name'] = $this->request->post['wishlist_name'];
                }
                elseif($wishlist['wishlist_name']){
                    $data['wishlist_name'] = $wishlist['wishlist_name'];
                }
                else {
                    $data['wishlist_name'] = '';
                }

                if (isset($this->request->post['visiblity'])) {
                    $data['visiblity'] = $this->request->post['visiblity'];
                }
                elseif($wishlist['visiblity']){
                    $data['visiblity'] = $wishlist['visiblity'];
                }
                else {
                    $data['visiblity'] = 0;
                }

                if (isset($this->request->post['status'])) {
                    $data['status'] = $this->request->post['status'];
                }
                elseif($wishlist['status']){
                    $data['status'] = $wishlist['status'];
                }
                else {
                    $data['status'] = 0;
                }
                
                /*
                if (isset($this->request->post['purchased_by'])) {
                    $data['purchased_by'] = $this->request->post['purchased_by'];
                }
                elseif($wishlist['purchased_by']){
                    $data['purchased_by'] = $wishlist['purchased_by'];
                }
                else {
                    $data['purchased_by'] = 0;
                }
                */
                
                $this->model_account_wishlists->editWishlists($data);

                $json['success'] = "Your wishList has updated Successfully!.";

            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));


	}
	
	public function editWishlistitem(){

        $this->load->model('account/wishlists');

        $this->load->model('catalog/product');

        $json = array();

        $data['text_success'] = $this->language->get('text_success');

        if (isset($this->request->post['wishlist_id'])) {
            $wishlist_id = $this->request->post['wishlist_id'];
        } else {
            $wishlist_id = 0;
        }

        if (isset($this->request->post['product_id'])) {
            $product_id = $this->request->post['product_id'];
        } else {
            $product_id = 0;
        }

        if($wishlist_id != 0 && $product_id != 0 ) {

            $data['wishlist_id'] = $wishlist_id;
            $data['product_id'] = $product_id;

            $wishlist = $this->model_account_wishlists->getWishlistitem($wishlist_id,$product_id);

            if ($wishlist) {
               
               if($this->customer->getId()){
                    $data['purchased_by'] = $this->customer->getId();;
                }
                else {
                    $data['purchased_by'] = 0;
                }                   
                
                $this->model_account_wishlists->editWishlistitem($data);

                $json['success'] = "Your wishList has updated Successfully!.";

            }
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
		
	}


//getwishlists
    public function getwishlists(){

        $json = array();
        
        $customer = ($this->customer->isLogged())?$this->customer->getId():0;
        

        if ($customer) {

            $this->load->model('account/wishlists');
            
            $wishparams['customer']= $customer;
            /*
					$wishlists = $this->model_account_wishlists->getWishlists($wishparams);
						if(is_array($wishlists)){
							foreach ($wishlists as $wishlist){
								$this->data['wishlists'][] = array(
									'wishlist_id'=> $wishlist['wishlist_id'],
									'wishlist_name'=> $wishlist['wishlist_name'],
								);
							}
						}
            
            */

            $filter_data = array(
                'customer'  => $customer,
            );

            $results = $this->model_account_wishlists->getWishlists($filter_data);

            foreach ($results as $result) {
                $json[$result['wishlist_id']] = $result['wishlist_name'];
                
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));

    }


    /* Filter Wishlist name */
    public function autocomplete(){

        $json = array();

        if (isset($this->request->get['wishlist_name'])) {

            $this->load->model('account/wishlists');

            if (isset($this->request->get['wishlist_name'])) {
                $wishlist_name = $this->request->get['wishlist_name'];
            } else {
                $wishlist_name = '';
            }

            $filter_data = array(
                'wishlist_name'  => $wishlist_name,

            //    'start'        => 0,
            //    'limit'        => $limit
            );

            $results = $this->model_account_wishlists->getWishlists($filter_data);

            foreach ($results as $result) {
                $option_data = array();


                $json[] = array(
                    'wishlist_id' => $result['wishlist_id'],
                    'wishlist_name'       => $result['wishlist_name']
                );
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));

    }
}
