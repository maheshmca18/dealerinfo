Now works on OpenCart 2.x!

Extension Features
==============================================================================================================
** Multiple Wishlists.
** The Multiple wishlists extension for your customers or it can be used as a Wedding List that will bring all their friends to your shop and buy from you!
** The Module allows customers to create multiple wishlists to which they can add products.
** Wishlist owner/customer can share his wishlist to friends via social media.

With the Multiple wishlists extension your customers can:
--------------------------------------------------------------------------------------------------------------
** Create and manage multiple Wishlists.
** Add Products to Wishlist from the Product Page or the Category page or Search Page.
** Keep track of the products that have been purchased.
** Keep track of the products that have been purchased by whom (His friends).
** Share the Wishlists through email and social shares.
** Make Wishlist with public or private access.
** Add products to the Wishlist from the shops product pages or Category page or Search Page.

Extension Features:-
--------------------------------------------------------------------------------------------------------------
** Every customer can create Multiple Wishlists.
** Wishlist saves in to the DB.
** Popup view.
** Ajax processing.
** Responsive.
** Installation by one click.
** Wishlists can share to friends [Facebook, Twitter, Google+, Linkedin, Tumblr, Pinterest]


DEMO
==============================================================================================================
Admin Access
------------
http://ocdemo.indialocal.co.in/opc2020/admin/
username: wishlistsadmin
password: wishlistsadmin

Store Front Access
------------
http://ocdemo.indialocal.co.in/opc2020
customer: customerwishlist@test.com
password: customer

Requirements
==============================================================================================================
PHP 5.2 or later
OpenCart 2.x
