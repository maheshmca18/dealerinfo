==========================================
Read Me : Import Customer
==========================================

Admin Login :

1. Go to the Customers list Page 

		:- Sales> Customers > Customers

		:- See import button Top Right corner and click here.

2. View Customer Import Screen.

		:- Click "Sample Excel file" on the Top Right corner to customerlist sample excel file (downloaded).

                :- Upload your Excel file [Note: Like our Sample file].

                :- Click Save button on Top Right corner.
 
 		:- Preview Your uploaded file Customer data.

                :- Now Click "Publish" button to import all customer data.

3. Done.