<?php
// Heading
$_['heading_title']       = 'Order Success Page Print & PDF';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module Order Success Page Settings!';

// Entry
$_['entry_displayordersuccess']   = 'Display Order Info On Success Page';
$_['entry_beforeorder']    = 'Miscellaneous HTML before Order Info';
$_['entry_afterorder']        = 'Miscellaneous HTML after Order Info';

$_['entry_msgbeforeorder']        = '!This will be displayed just before order info';
$_['entry_msgafterorder']        = '!This will be displayed just after order info';

$_['text_enabled'] 		  = 'Enabled';
$_['text_disabled'] 	  = 'Disabled';


?>
