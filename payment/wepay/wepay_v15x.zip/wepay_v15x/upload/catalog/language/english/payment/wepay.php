<?php
// Text
$_['text_title']       = 'Credit Card (Processed By WePay)';
$_['text_instruction'] = 'WePay';
$_['text_instruction_2'] = 'You will be redirected to WePay to take payment when you hit the confirm order button. Once payment is made we will start processing your order.';
?>