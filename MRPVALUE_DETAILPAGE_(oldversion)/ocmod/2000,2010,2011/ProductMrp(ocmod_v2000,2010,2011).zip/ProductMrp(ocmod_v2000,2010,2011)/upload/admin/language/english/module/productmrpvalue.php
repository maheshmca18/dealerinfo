<?php
// Heading
$_['heading_title']    = 'Product MRP Value';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';