<?php
// Heading
$_['heading_title']    = 'Product MRP Value';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';
$_['text_status_enabled']             = 'Enabled';
$_['text_status_disabled']            = 'Disabled';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';
