<?php
// Heading
$_['heading_title']    = 'Deal of the Day';


// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Deal of the Day!';
$_['text_edit']        = 'Edit Deal of the Day Module';
/*$_['text_min_day']                    = 'Minimum Day';
$_['text_max_day']                    = 'Maximum Day';*/
$_['text_status_enabled']             = 'Enabled';
$_['text_status_disabled']            = 'Disabled';

// Entry
$_['entry_admin']      = 'Label Option';
$_['entry_status']     = 'Status';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Deal of the Day !';
