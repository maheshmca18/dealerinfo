<?php
// Heading
$_['heading_title']    = 'Weight Based Delivery';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Weight Based Delivery module!';