<?php
// Heading
$_['heading_title']    = 'Product of the Day';


// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified product of the Day!';
$_['text_edit']        = 'Edit product of the Day Module';
/*$_['text_min_day']                    = 'Minimum Day';
$_['text_max_day']                    = 'Maximum Day';*/
$_['text_status_enabled']             = 'Enabled';
$_['text_status_disabled']            = 'Disabled';

// Entry
$_['entry_admin']      = 'Label Option';
$_['entry_status']     = 'Status';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify product of the Day !';
