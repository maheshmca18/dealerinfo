<?php
$name='FreeSansBold';
$type='TTF';
$desc=array (
  'CapHeight' => 729,
  'XHeight' => 540,
  'FontBBox' => '[-968 -460 1556 1066]',
  'Flags' => 262148,
  'Ascent' => 900,
  'Descent' => -300,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 135,
  'MissingWidth' => 800,
);
$unitsPerEm=1000;
$up=-189;
$ut=69;
$strp=258;
$strs=49;
$ttffile='C:/xampp/htdocs/opc/opc_pdf/opc_pdf_2302_vq/system/library/mpdf60/ttfonts/FreeSansBold.ttf';
$TTCfontID='0';
$originalsize=416128;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='freesansB';
$panose=' 8 5 2 b 7 4 2 2 2 2 2 4';
$haskerninfo=true;
$haskernGPOS=true;
$hassmallcapsGSUB=true;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 800, -200, 100
// usWinAscent/usWinDescent = 900, -300
// hhea Ascent/Descent/LineGap = 900, -200, 100
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'DFLT' => 'DFLT ',
  'armn' => 'DFLT ',
  'cyrl' => 'DFLT MKD  SRB  ',
  'dev2' => 'DFLT SAN  ',
  'deva' => 'DFLT SAN  ',
  'grek' => 'DFLT ',
  'gur2' => 'DFLT ',
  'guru' => 'DFLT ',
  'hebr' => 'DFLT ',
  'latn' => 'DFLT CAT  ISM  LSM  NSM  SKS  TRK  nl   ',
);
$GSUBFeatures=array (
  'DFLT' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 6,
      ),
      'pnum' => 
      array (
        0 => 13,
      ),
      'zero' => 
      array (
        0 => 14,
      ),
      'frac' => 
      array (
        0 => 16,
      ),
    ),
  ),
  'armn' => 
  array (
    'DFLT' => 
    array (
      'dlig' => 
      array (
        0 => 19,
      ),
      'hlig' => 
      array (
        0 => 20,
      ),
    ),
  ),
  'cyrl' => 
  array (
    'DFLT' => 
    array (
      'pnum' => 
      array (
        0 => 13,
      ),
      'liga' => 
      array (
        0 => 18,
      ),
    ),
    'MKD ' => 
    array (
      'locl' => 
      array (
        0 => 17,
      ),
    ),
    'SRB ' => 
    array (
      'locl' => 
      array (
        0 => 17,
      ),
    ),
  ),
  'dev2' => 
  array (
    'DFLT' => 
    array (
      'nukt' => 
      array (
        0 => 29,
      ),
      'akhn' => 
      array (
        0 => 30,
      ),
      'rphf' => 
      array (
        0 => 31,
      ),
      'blwf' => 
      array (
        0 => 32,
        1 => 33,
      ),
      'half' => 
      array (
        0 => 34,
      ),
      'vatu' => 
      array (
        0 => 35,
      ),
      'pres' => 
      array (
        0 => 36,
        1 => 37,
        2 => 38,
        3 => 40,
      ),
      'abvs' => 
      array (
        0 => 41,
      ),
      'blws' => 
      array (
        0 => 42,
        1 => 44,
      ),
      'locl' => 
      array (
        0 => 43,
      ),
    ),
    'SAN ' => 
    array (
      'nukt' => 
      array (
        0 => 29,
      ),
      'akhn' => 
      array (
        0 => 30,
      ),
      'rphf' => 
      array (
        0 => 31,
      ),
      'blwf' => 
      array (
        0 => 32,
        1 => 33,
      ),
      'half' => 
      array (
        0 => 34,
      ),
      'vatu' => 
      array (
        0 => 35,
      ),
      'pres' => 
      array (
        0 => 36,
        1 => 37,
        2 => 38,
        3 => 39,
      ),
      'abvs' => 
      array (
        0 => 41,
      ),
      'blws' => 
      array (
        0 => 42,
        1 => 44,
      ),
      'locl' => 
      array (
        0 => 43,
      ),
    ),
  ),
  'deva' => 
  array (
    'DFLT' => 
    array (
      'nukt' => 
      array (
        0 => 29,
      ),
      'akhn' => 
      array (
        0 => 30,
      ),
      'rphf' => 
      array (
        0 => 31,
      ),
      'blwf' => 
      array (
        0 => 32,
        1 => 33,
      ),
      'half' => 
      array (
        0 => 34,
      ),
      'vatu' => 
      array (
        0 => 35,
      ),
      'pres' => 
      array (
        0 => 36,
        1 => 37,
        2 => 38,
        3 => 40,
      ),
      'abvs' => 
      array (
        0 => 41,
      ),
      'blws' => 
      array (
        0 => 42,
        1 => 44,
      ),
      'locl' => 
      array (
        0 => 43,
      ),
    ),
    'SAN ' => 
    array (
      'nukt' => 
      array (
        0 => 29,
      ),
      'akhn' => 
      array (
        0 => 30,
      ),
      'rphf' => 
      array (
        0 => 31,
      ),
      'blwf' => 
      array (
        0 => 32,
        1 => 33,
      ),
      'half' => 
      array (
        0 => 34,
      ),
      'vatu' => 
      array (
        0 => 35,
      ),
      'pres' => 
      array (
        0 => 36,
        1 => 37,
        2 => 38,
        3 => 39,
      ),
      'abvs' => 
      array (
        0 => 41,
      ),
      'blws' => 
      array (
        0 => 42,
        1 => 44,
      ),
      'locl' => 
      array (
        0 => 43,
      ),
    ),
  ),
  'grek' => 
  array (
    'DFLT' => 
    array (
      'pnum' => 
      array (
        0 => 13,
      ),
    ),
  ),
  'gur2' => 
  array (
    'DFLT' => 
    array (
      'blwf' => 
      array (
        0 => 23,
      ),
      'nukt' => 
      array (
        0 => 24,
      ),
      'pstf' => 
      array (
        0 => 25,
      ),
      'blws' => 
      array (
        0 => 26,
      ),
      'abvs' => 
      array (
        0 => 27,
      ),
      'psts' => 
      array (
        0 => 28,
      ),
    ),
  ),
  'guru' => 
  array (
    'DFLT' => 
    array (
      'blwf' => 
      array (
        0 => 23,
      ),
      'nukt' => 
      array (
        0 => 24,
      ),
      'pstf' => 
      array (
        0 => 25,
      ),
      'blws' => 
      array (
        0 => 26,
      ),
      'abvs' => 
      array (
        0 => 27,
      ),
      'psts' => 
      array (
        0 => 28,
      ),
    ),
  ),
  'hebr' => 
  array (
    'DFLT' => 
    array (
      'dlig' => 
      array (
        0 => 21,
      ),
      'ccmp' => 
      array (
        0 => 22,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 6,
        2 => 10,
        3 => 11,
      ),
      'smcp' => 
      array (
        0 => 2,
      ),
      'c2sc' => 
      array (
        0 => 4,
      ),
      'liga' => 
      array (
        0 => 8,
      ),
      'hlig' => 
      array (
        0 => 9,
      ),
      'pnum' => 
      array (
        0 => 13,
      ),
    ),
    'CAT ' => 
    array (
      'liga' => 
      array (
        0 => 7,
      ),
    ),
    'ISM ' => 
    array (
      'locl' => 
      array (
        0 => 15,
      ),
    ),
    'LSM ' => 
    array (
      'locl' => 
      array (
        0 => 15,
      ),
    ),
    'NSM ' => 
    array (
      'locl' => 
      array (
        0 => 15,
      ),
    ),
    'SKS ' => 
    array (
      'locl' => 
      array (
        0 => 15,
      ),
    ),
    'TRK ' => 
    array (
      'smcp' => 
      array (
        0 => 1,
      ),
      'c2sc' => 
      array (
        0 => 3,
      ),
    ),
    'nl  ' => 
    array (
      'liga' => 
      array (
        0 => 12,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388342,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388374,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388392,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388524,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388536,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388668,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388688,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388814,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 388852,
      1 => 388928,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 388988,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 389012,
      1 => 389094,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 389324,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 389638,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 389676,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 389692,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 389704,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 389716,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390018,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390030,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390054,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390116,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 4,
    'Flag' => 8,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390140,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 2,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390164,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390424,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390484,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 390998,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391022,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391122,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391176,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391228,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391350,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391376,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 391400,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 391424,
      1 => 391506,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 391590,
      1 => 391702,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 392206,
      1 => 392244,
      2 => 392352,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 392376,
      1 => 392432,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 392496,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 392534,
      1 => 392740,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 392786,
      1 => 392910,
      2 => 392948,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393244,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393334,
    ),
    'MarkFilteringSet' => '',
  ),
  42 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393408,
    ),
    'MarkFilteringSet' => '',
  ),
  43 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393492,
    ),
    'MarkFilteringSet' => '',
  ),
  44 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393510,
    ),
    'MarkFilteringSet' => '',
  ),
  45 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393616,
    ),
    'MarkFilteringSet' => '',
  ),
  46 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393640,
    ),
    'MarkFilteringSet' => '',
  ),
  47 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393664,
    ),
    'MarkFilteringSet' => '',
  ),
  48 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 393676,
      1 => 393702,
      2 => 393728,
    ),
    'MarkFilteringSet' => '',
  ),
  49 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 393754,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'DFLT' => 'DFLT ',
  'armn' => 'DFLT ',
  'cyrl' => 'DFLT ',
  'dev2' => 'DFLT SAN  ',
  'deva' => 'DFLT SAN  ',
  'geor' => 'DFLT ',
  'grek' => 'DFLT ',
  'gur2' => 'DFLT ',
  'guru' => 'DFLT ',
  'hebr' => 'DFLT IWR  JII  ',
  'latn' => 'DFLT ',
);
$GPOSFeatures=array (
  'DFLT' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 8,
      ),
    ),
  ),
  'armn' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 8,
      ),
    ),
  ),
  'cyrl' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 1,
      ),
      'mark' => 
      array (
        0 => 8,
        1 => 9,
      ),
    ),
  ),
  'dev2' => 
  array (
    'DFLT' => 
    array (
      'abvm' => 
      array (
        0 => 17,
      ),
      'blwm' => 
      array (
        0 => 18,
        1 => 19,
        2 => 21,
      ),
      'mkmk' => 
      array (
        0 => 20,
      ),
      'dist' => 
      array (
        0 => 22,
      ),
    ),
    'SAN ' => 
    array (
      'blwm' => 
      array (
        0 => 19,
        1 => 21,
      ),
    ),
  ),
  'deva' => 
  array (
    'DFLT' => 
    array (
      'abvm' => 
      array (
        0 => 17,
      ),
      'blwm' => 
      array (
        0 => 18,
        1 => 19,
        2 => 21,
      ),
      'mkmk' => 
      array (
        0 => 20,
      ),
      'dist' => 
      array (
        0 => 22,
      ),
    ),
    'SAN ' => 
    array (
      'blwm' => 
      array (
        0 => 19,
        1 => 21,
      ),
    ),
  ),
  'geor' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 8,
      ),
    ),
  ),
  'grek' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 2,
        1 => 3,
        2 => 8,
      ),
    ),
  ),
  'gur2' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 8,
      ),
    ),
  ),
  'guru' => 
  array (
    'DFLT' => 
    array (
      'abvm' => 
      array (
        0 => 13,
      ),
      'blwm' => 
      array (
        0 => 14,
        1 => 16,
      ),
      'mkmk' => 
      array (
        0 => 15,
      ),
    ),
  ),
  'hebr' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 8,
        1 => 11,
        2 => 12,
      ),
    ),
    'IWR ' => 
    array (
      'mark' => 
      array (
        0 => 11,
        1 => 12,
      ),
    ),
    'JII ' => 
    array (
      'mark' => 
      array (
        0 => 10,
        1 => 12,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 4,
        1 => 5,
        2 => 6,
        3 => 7,
        4 => 8,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 394516,
      1 => 396830,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 398440,
      1 => 398516,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 398806,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 398852,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 399068,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 402058,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 404090,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 406050,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 406342,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 407258,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 408156,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 408322,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 257,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 408974,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 410420,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 411014,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 411584,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 411682,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 412536,
      1 => 412682,
      2 => 412838,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 414016,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 415026,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 415588,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 415668,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 416006,
    ),
    'MarkFilteringSet' => '',
  ),
);
$kerninfo=array (
  1027 => 
  array (
    1028 => -20,
    1040 => -30,
    1047 => -20,
    1054 => -20,
    1057 => -20,
    1060 => -20,
    1069 => -20,
    1071 => -20,
    1072 => -30,
    1074 => -30,
    1075 => -30,
    1076 => -30,
    1077 => -30,
    1078 => -30,
    1079 => -30,
    1080 => -30,
    1081 => -30,
    1082 => -30,
    1083 => -30,
    1084 => -30,
    1085 => -30,
    1086 => -30,
    1087 => -30,
    1088 => -30,
    1089 => -30,
    1090 => -30,
    1091 => -30,
    1092 => -30,
    1093 => -30,
    1094 => -30,
    1095 => -30,
    1096 => -30,
    1097 => -30,
    1098 => -30,
    1099 => -30,
    1100 => -30,
    1101 => -30,
    1102 => -30,
    1103 => -30,
    1104 => -30,
    1105 => -30,
    1106 => -30,
    1107 => -30,
    1108 => -30,
    1109 => -30,
    1110 => -30,
    1111 => -30,
    1112 => -30,
    1113 => -30,
    1114 => -30,
    1115 => -30,
    1116 => -30,
    1117 => -30,
    1118 => -30,
    1119 => -30,
  ),
  1028 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1036 => 
  array (
    1028 => -40,
    1047 => -40,
    1054 => -40,
    1057 => -40,
    1058 => -20,
    1060 => -40,
    1069 => -40,
    1071 => -20,
    1072 => -20,
    1074 => -20,
    1075 => -20,
    1076 => -20,
    1077 => -20,
    1078 => -20,
    1079 => -20,
    1080 => -20,
    1081 => -20,
    1082 => -20,
    1083 => -20,
    1084 => -20,
    1085 => -20,
    1086 => -20,
    1087 => -20,
    1088 => -20,
    1089 => -20,
    1090 => -20,
    1091 => -20,
    1092 => -20,
    1093 => -20,
    1094 => -20,
    1095 => -20,
    1096 => -20,
    1097 => -20,
    1098 => -20,
    1099 => -20,
    1100 => -20,
    1101 => -20,
    1102 => -20,
    1103 => -20,
    1104 => -20,
    1105 => -20,
    1106 => -20,
    1107 => -20,
    1108 => -20,
    1109 => -20,
    1110 => -20,
    1111 => -20,
    1112 => -20,
    1113 => -20,
    1114 => -20,
    1115 => -20,
    1116 => -20,
    1117 => -20,
    1118 => -20,
    1119 => -20,
  ),
  1038 => 
  array (
    1028 => -30,
    1040 => -40,
    1047 => -30,
    1054 => -30,
    1057 => -30,
    1060 => -30,
    1069 => -30,
    1071 => -30,
    1072 => -30,
    1074 => -30,
    1075 => -30,
    1076 => -30,
    1077 => -30,
    1078 => -30,
    1079 => -30,
    1080 => -30,
    1081 => -30,
    1082 => -30,
    1083 => -30,
    1084 => -30,
    1085 => -30,
    1086 => -30,
    1087 => -30,
    1088 => -30,
    1089 => -30,
    1090 => -30,
    1091 => -30,
    1092 => -30,
    1093 => -30,
    1094 => -30,
    1095 => -30,
    1096 => -30,
    1097 => -30,
    1098 => -30,
    1099 => -30,
    1100 => -30,
    1101 => -30,
    1102 => -30,
    1103 => -30,
    1104 => -30,
    1105 => -30,
    1106 => -30,
    1107 => -30,
    1108 => -30,
    1109 => -30,
    1110 => -30,
    1111 => -30,
    1112 => -30,
    1113 => -30,
    1114 => -30,
    1115 => -30,
    1116 => -30,
    1117 => -30,
    1118 => -30,
    1119 => -30,
  ),
  1043 => 
  array (
    1028 => -20,
    1040 => -30,
    1047 => -20,
    1054 => -20,
    1057 => -20,
    1060 => -20,
    1069 => -20,
    1071 => -20,
    1072 => -30,
    1074 => -30,
    1075 => -30,
    1076 => -30,
    1077 => -30,
    1078 => -30,
    1079 => -30,
    1080 => -30,
    1081 => -30,
    1082 => -30,
    1083 => -30,
    1084 => -30,
    1085 => -30,
    1086 => -30,
    1087 => -30,
    1088 => -30,
    1089 => -30,
    1090 => -30,
    1091 => -30,
    1092 => -30,
    1093 => -30,
    1094 => -30,
    1095 => -30,
    1096 => -30,
    1097 => -30,
    1098 => -30,
    1099 => -30,
    1100 => -30,
    1101 => -30,
    1102 => -30,
    1103 => -30,
    1104 => -30,
    1105 => -30,
    1106 => -30,
    1107 => -30,
    1108 => -30,
    1109 => -30,
    1110 => -30,
    1111 => -30,
    1112 => -30,
    1113 => -30,
    1114 => -30,
    1115 => -30,
    1116 => -30,
    1117 => -30,
    1118 => -30,
    1119 => -30,
  ),
  1047 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1050 => 
  array (
    1028 => -40,
    1047 => -40,
    1054 => -40,
    1057 => -40,
    1058 => -20,
    1060 => -40,
    1069 => -40,
    1071 => -20,
    1072 => -20,
    1074 => -20,
    1075 => -20,
    1076 => -20,
    1077 => -20,
    1078 => -20,
    1079 => -20,
    1080 => -20,
    1081 => -20,
    1082 => -20,
    1083 => -20,
    1084 => -20,
    1085 => -20,
    1086 => -20,
    1087 => -20,
    1088 => -20,
    1089 => -20,
    1090 => -20,
    1091 => -20,
    1092 => -20,
    1093 => -20,
    1094 => -20,
    1095 => -20,
    1096 => -20,
    1097 => -20,
    1098 => -20,
    1099 => -20,
    1100 => -20,
    1101 => -20,
    1102 => -20,
    1103 => -20,
    1104 => -20,
    1105 => -20,
    1106 => -20,
    1107 => -20,
    1108 => -20,
    1109 => -20,
    1110 => -20,
    1111 => -20,
    1112 => -20,
    1113 => -20,
    1114 => -20,
    1115 => -20,
    1116 => -20,
    1117 => -20,
    1118 => -20,
    1119 => -20,
  ),
  1054 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1056 => 
  array (
    1028 => -10,
    1040 => -30,
    1047 => -10,
    1054 => -10,
    1057 => -10,
    1060 => -10,
    1069 => -10,
    1071 => -10,
    1072 => -20,
    1074 => -20,
    1075 => -20,
    1076 => -20,
    1077 => -20,
    1078 => -20,
    1079 => -20,
    1080 => -20,
    1081 => -20,
    1082 => -20,
    1083 => -20,
    1084 => -20,
    1085 => -20,
    1086 => -20,
    1087 => -20,
    1088 => -20,
    1089 => -20,
    1090 => -20,
    1091 => -20,
    1092 => -20,
    1093 => -20,
    1094 => -20,
    1095 => -20,
    1096 => -20,
    1097 => -20,
    1098 => -20,
    1099 => -20,
    1100 => -20,
    1101 => -20,
    1102 => -20,
    1103 => -20,
    1104 => -20,
    1105 => -20,
    1106 => -20,
    1107 => -20,
    1108 => -20,
    1109 => -20,
    1110 => -20,
    1111 => -20,
    1112 => -20,
    1113 => -20,
    1114 => -20,
    1115 => -20,
    1116 => -20,
    1117 => -20,
    1118 => -20,
    1119 => -20,
  ),
  1057 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1058 => 
  array (
    1028 => -20,
    1040 => -30,
    1047 => -20,
    1054 => -20,
    1057 => -20,
    1060 => -20,
    1069 => -20,
    1071 => -20,
    1072 => -30,
    1074 => -30,
    1075 => -30,
    1076 => -30,
    1077 => -30,
    1078 => -30,
    1079 => -30,
    1080 => -30,
    1081 => -30,
    1082 => -30,
    1083 => -30,
    1084 => -30,
    1085 => -30,
    1086 => -30,
    1087 => -30,
    1088 => -30,
    1089 => -30,
    1090 => -30,
    1091 => -30,
    1092 => -30,
    1093 => -30,
    1094 => -30,
    1095 => -30,
    1096 => -30,
    1097 => -30,
    1098 => -30,
    1099 => -30,
    1100 => -30,
    1101 => -30,
    1102 => -30,
    1103 => -30,
    1104 => -30,
    1105 => -30,
    1106 => -30,
    1107 => -30,
    1108 => -30,
    1109 => -30,
    1110 => -30,
    1111 => -30,
    1112 => -30,
    1113 => -30,
    1114 => -30,
    1115 => -30,
    1116 => -30,
    1117 => -30,
    1118 => -30,
    1119 => -30,
  ),
  1059 => 
  array (
    1028 => -30,
    1040 => -40,
    1047 => -30,
    1054 => -30,
    1057 => -30,
    1060 => -30,
    1069 => -30,
    1071 => -30,
    1072 => -30,
    1074 => -30,
    1075 => -30,
    1076 => -30,
    1077 => -30,
    1078 => -30,
    1079 => -30,
    1080 => -30,
    1081 => -30,
    1082 => -30,
    1083 => -30,
    1084 => -30,
    1085 => -30,
    1086 => -30,
    1087 => -30,
    1088 => -30,
    1089 => -30,
    1090 => -30,
    1091 => -30,
    1092 => -30,
    1093 => -30,
    1094 => -30,
    1095 => -30,
    1096 => -30,
    1097 => -30,
    1098 => -30,
    1099 => -30,
    1100 => -30,
    1101 => -30,
    1102 => -30,
    1103 => -30,
    1104 => -30,
    1105 => -30,
    1106 => -30,
    1107 => -30,
    1108 => -30,
    1109 => -30,
    1110 => -30,
    1111 => -30,
    1112 => -30,
    1113 => -30,
    1114 => -30,
    1115 => -30,
    1116 => -30,
    1117 => -30,
    1118 => -30,
    1119 => -30,
  ),
  1060 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1066 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1068 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1069 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1070 => 
  array (
    1058 => -20,
    1071 => -20,
  ),
  1075 => 
  array (
    1076 => -40,
  ),
  1090 => 
  array (
    1076 => -40,
  ),
  1091 => 
  array (
    1076 => -20,
  ),
  1118 => 
  array (
    1076 => -20,
  ),
  2308 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2309 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2310 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2311 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2312 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2313 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2314 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2315 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2316 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2317 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2318 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2319 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2320 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2321 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2322 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2323 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2324 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2325 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2326 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2327 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2328 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2329 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2330 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2331 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2332 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2333 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2334 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2335 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2336 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2337 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2338 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2339 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2340 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2341 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2342 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2343 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2344 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2345 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2346 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2347 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2348 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2349 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2350 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2351 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2352 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2353 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2354 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2355 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2356 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2357 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2358 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2359 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2360 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2361 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2362 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2363 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2364 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2366 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2367 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2368 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2369 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2370 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2371 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2372 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2373 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2374 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2375 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2376 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2377 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2378 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2379 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2380 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2381 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2382 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2383 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2384 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2385 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2386 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2387 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2388 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2389 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2390 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2391 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2392 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2393 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2394 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2395 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2396 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2397 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2398 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2399 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2400 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2401 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2402 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2403 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2406 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2407 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2408 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2409 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2410 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2411 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2412 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2413 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2414 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2415 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2416 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2417 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2418 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2419 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2420 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2421 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2422 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2423 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2425 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2426 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2427 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2428 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2429 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2430 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
  2431 => 
  array (
    33 => 220,
    58 => 220,
    59 => 220,
    63 => 200,
  ),
);
?>