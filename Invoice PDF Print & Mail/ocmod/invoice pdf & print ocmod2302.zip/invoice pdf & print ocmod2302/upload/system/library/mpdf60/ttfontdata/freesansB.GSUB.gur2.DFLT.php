<?php

$rtlSUB = array();
$finals = '';
$rphf = array (
);
$half = array (
);
$pref = array (
);
$blwf = array (
  2608 => 57346,
  2613 => 57347,
  2617 => 57348,
);
$pstf = array (
  2607 => 57349,
);

 
?>