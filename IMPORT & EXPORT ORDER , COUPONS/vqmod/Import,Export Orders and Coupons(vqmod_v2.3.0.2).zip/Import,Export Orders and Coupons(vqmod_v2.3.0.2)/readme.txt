==========================================
Read Me : Import,Export Orders and Coupons
==========================================

Admin Login :

==========================================
Orders Import & Export
==========================================


1. Go to the Orders list Page 

		Sales -> Orders 
              
                See Import Button & Export Button Top Right corner.


2. Click to Export Button and  Export Orders list as excel file (downloaded).

3. Click to Import Button 

                -> View Orders Import Screen.

		-> Click "Sample CSV file" on the Top Right corner to Orderslist sample excel/CSV file (downloaded).

                -> Upload your Excel/CSV file [Note: Like our Sample file].

                -> Click Save button on Top Right corner.
 
 		-> Preview Your uploaded file Orders data.

                -> Now Click "Publish" button to import all Orders data.





==========================================
Coupons Import & Export
==========================================

1. Go to the Coupons list Page 

		Marketing -> Coupons

	        See Import Button & Export Button Top Right corner.

2. Click to Export Button and Export Coupons list as excel file (downloaded).

3. Click to Import Button

		-> View Coupons Import Screen.

		-> Click "Sample CSV file" on the Top Right corner to Couponslist sample excel/CSV file (downloaded).

                -> Upload your Excel/CSV file [Note: Like our Sample file].

                -> Click Save button on Top Right corner.
 
 		-> Preview Your uploaded file Coupons data.

                -> Now Click "Publish" button to import all Coupons data.



------------------------------------------------------------------------------------------------------------------------
				Coupons CSV File
------------------------------------------------------------------------------------------------------------------------
		1. Coupon Name
		2. Coupon Code	
		3. Type		
		4. Discount
		5. Logged
		6. Shipping
   		7. Total
		8. Coupon Products
		9. Coupon Categories
		10.Coupon Date Start
		11.Coupon Date End
		12.Uses Per Coupon
		13.Uses Per Customer
		14. Status  [Enabled/Disabled]

-----------------------------------------------------------------------------------------------------------------------
		
	
------------------------------------------------------------------------------------------------------------------------
				Orders CSV File 
------------------------------------------------------------------------------------------------------------------------
		1. Invoice_no
		2. Currency	
		3. Customer	
		4. Customer Group	
		5. Customer First Name	
		6. Customer Last Name	
		7. Customer E-Mail	
		8. Customer Telephone	
		9. Customer Fax	
		10. Product	
		11. Quantity	
		12. Total	
		13. Product option Name	
		14. Product option Value	
		15. Product option Type

		16. Voucher Description
		17. Voucher Code	
		18. Voucher Recipient Name		
		19. Voucher Recipient Email	
		20. Voucher Senders Name	
		21. Voucher Senders Email	
		22. Voucher Gift Certificate Theme	
		23. Voucher Message	
		24. Voucher Amount
	
		25. payment First Name
		26. payment Last Name
		27. payment Company	
		28. payment Address 1
		29. payment Address 2	
		30. payment City	
		31. payment Postcode	
		32. payment Country	
		33. payment Region / State
	
		34. Shipping First Name	
		35. Shipping Last Name
		36. Shipping Company
		37. Shipping Address 1
		38. Shipping Address 2
		39. Shipping City
		40. Shipping Postcode
		41. Shipping Country
		42. Shipping Region / State
		43. Shipping Method
		44. Payment Method
		45. Coupon
		46. Voucher
		47. Reward
		48. Order Status
		49. Comment
		50. Affiliate
		51. Code
		52. Title
		53. Value

-----------------------------------------------------------------------------------------------------------------------



























-----------------------------------------------------------------------------------------------------------------------
		
